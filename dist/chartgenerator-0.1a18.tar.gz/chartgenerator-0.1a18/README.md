# chartgenerator

Generate candlestick charts from json market data, automatically calculate support and resistance levels, and graph using Plot.ly.
